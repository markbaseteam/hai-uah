
Artificial Intelligence is far from being really intelligent.  Currrently is restricted to local skills.

Using algorithms we can implement amazing skills in computers to do certain tasks better than humans.  However, at the moment we cannot create really intelligent systems in the same sense of [[Human Intelligence]]

We believe that the way to improve the computer systems is to combine their  algorithms with information provided by human intelligence. This imformation  