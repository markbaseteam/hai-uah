
This is the ability to explain processes and situations within a context and using